
public class Main {

	public static void main(String[] args) {


		
//	Student st1 = new Student("111", 2001, "AA", "BB", "01.01.2000.");
//	Student st2 = new Student("222", 2001, "CC", "DD", "01.01.2000.");
//	Student st3 = new Student("333", 2001, "EE", "FF", "01.01.2000.");
//	
//	Student [] studenti = {st1, st2, st3};
//	
//	Ispit is1 = new Ispit(10, "Matematika 1");
//	Ispit is2 = new Ispit(20, "Matematika 2");
//	Ispit is3 = new Ispit(30, "Fizika");
	
//	Student [] studenti = {st1, st2, st3};
	
//	Ispit [] ispiti = {is1, is2, is3};
//	
//	for (int i = 0; i < ispiti.length; i++) {
//		System.out.println(ispiti[i]);
//	}
	
//	for (int i = 0; i < studenti.length; i++) {
//		System.out.println(studenti[i]);
//		
//	}
		
		
//	public void stampajStudente() {
//		
//		for (int i = 0; i < studenti.length; i++) {
//		System.out.println(studenti[i]);
//	}
	
//	Niz niz = new Niz();
	
//	niz.stampajStudente();
		
//	niz.stampajIspite();	
	
		GlavniMeni gm = new GlavniMeni();
		gm.pravljenjeGlavnogMenija();
	}

}
